class InvalidState(Exception):
    pass