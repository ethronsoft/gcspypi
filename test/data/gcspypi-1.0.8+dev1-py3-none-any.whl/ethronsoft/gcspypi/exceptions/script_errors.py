class ScriptError(Exception):
    pass
