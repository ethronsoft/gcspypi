class NotFound(Exception):
    pass

class InvalidParameter(Exception):
    pass