class RepositoryError(Exception):
    pass
